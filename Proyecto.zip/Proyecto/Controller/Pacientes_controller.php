<?php
include_once '../Model/Pacientes_model.php';

function ConsultarPacientes() {
    $respuesta = ConsultarPacientesDB();

    if ($respuesta->num_rows > 0) {
        while ($row = mysqli_fetch_array($respuesta)) {
            echo "<tr>";
            echo "<td>" . $row["id"] . "</td>"; // Asegúrate de que la columna 'medicamento_id' exista si la necesitas
            echo "<td>" . $row["fecha_nacimiento"] . "</td>";
            echo "<td>" . $row["direccion"] . "</td>";
            echo "<td>" . $row["telefono"] . "</td>";
            echo "<td>" . $row["nombre"] . "</td>";
            echo "<td>" . $row["estado"] . "</td>";
            echo '<td>
                        <button type="button" class="btn btn-primary AbrirModal" data-toggle="modal" data-target="#ModalUsuarios" 
                        data-id=' . $row["id"] . ' data-name="' . $row["nombre"] . '">
                            <i class="fa fa-edit"></i>
                        </button>

                        <a href="actualizarPacientes.php?q=' . $row["id"] . '" class="btn btn-primary">
                            <i class="fa fa-user"></i>
                        </a>

                     </td>';
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No hay medicamentos disponibles</td></tr>";
    }
}


// Consultar medicamento por ID
function ConsultarPaciente($id) {
    $respuesta = ConsultarPacienteBD($id);
    if ($respuesta->num_rows > 0) {
        return mysqli_fetch_array($respuesta);
    }
}

if (isset($_POST["btnActualizarPaciente"])) {
    $id = $_POST["id"];
    $fecha_nacimiento = $_POST["fecha_nacimiento"];
    $direccion = $_POST["direccion"];
    $telefono = $_POST["telefono"];
    $nombre = $_POST["nombre"];

    ActualizarPaciente($id, $fecha_nacimiento, $direccion, $telefono, $nombre);
    header("Location: ../View/VisualizarPacientes.php");
    exit();
}


if(isset($_POST["btnRegistrarPaciente"])) {
    // Asegúrate de que todos los campos están definidos y no están vacíos
    $fecha_nacimiento = isset($_POST["fecha_nacimiento"]) ? trim($_POST["fecha_nacimiento"]) : '';
    $direccion = isset($_POST["direccion"]) ? trim($_POST["direccion"]) : '';
    $telefono = isset($_POST["telefono"]) ? trim($_POST["telefono"]) : '';
    $nombre = isset($_POST["nombre"]) ? trim($_POST["nombre"]) : '';

    if (!empty($fecha_nacimiento) && !empty($direccion) && !empty($telefono) && !empty($nombre)) {
        RegistrarPaciente($fecha_nacimiento, $direccion, $telefono, $nombre);
        header("Location: ../View/VisualizarPacientes.php");
        exit();
    } else {
        $msj = "Por favor, complete todos los campos.";
        header("Location: ../View/RegistrarMedicamentos.php?msj=" . urlencode($msj));
        exit();
    }
}


if(isset($_POST["btnCambiarEstadoUsuario"]))
{
    $id = $_POST["id"];
    $respuesta = CambiarEstadoUsuario($id);

    if($respuesta == true)
    {
        header("location: ../View/VisualizarPacientes.php");
    }
    else
    {
        $_POST["msj"] = "No se ha podido inactivar la información del usuario.";
    }
}



?>
