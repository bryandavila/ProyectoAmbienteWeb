<?php
include_once '../Model/procesar_registro.php';

if (isset($_POST["btnRegistrarUsuario"])) {
    $nombre = $_POST['nombre'];
    $identificacion = $_POST['identificacion'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $rol = $_POST['rol'];

    $respuesta = procesarRegistro($nombre, $identificacion, $email, $password, $rol);

    if (is_numeric($respuesta)) {
        // Redirección según el rol
        if ($rol == 1) {
            header("Location: ../View/registroPacientes.php?usuario_id={$respuesta}");
        } else if ($rol == 2) {
            header("Location: ../View/registroMedicos.php?usuario_id={$respuesta}");
        }
        exit(); // Es una buena práctica salir después de redirigir
    } else {
        // Mostrar error
        $error_registro = $respuesta;
    }
}


