<?php
include_once '../Model/procesar_registro.php';
include_once '../Model/procesarregistroPaciente_model.php';

if (isset($_POST["btnRegistrarUsuario2"])) {
    // Obtener datos del formulario
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];

    // Procesar el registro del usuario
    $respuesta_usuario = procesarRegistro($nombre, $identificacion, $email, $password, $rol);

    if ($respuesta_usuario === true) {
        // Obtener el último ID del usuario registrado
        $usuario_id = obtenerUltimoIDUsuario();

        // Procesar el registro del paciente con el usuario_id
        $respuesta_paciente = procesarRegistroPaciente($usuario_id, $fecha_nacimiento, $telefono, $direccion);

        // Verificar si el registro del paciente fue exitoso
        if ($respuesta_paciente) {
            if ($rol == 1) {
                header("Location: ../View/login.php?identificacion=$identificacion");
            } 
            exit(); // Es una buena práctica salir después de redirigir
        } else {
            echo "Error al registrar el paciente.";
        }
    } else {
        echo "Error al registrar el usuario.";
    }
} else {
    echo "Método no permitido.";
}
?>

