<?php
include_once '../Model/Medicamento_model.php';

function ConsultarMedicamentos() {
    $respuesta = ConsultarMedicamentosDB();

    if ($respuesta->num_rows > 0) {
        while ($row = mysqli_fetch_array($respuesta)) {
            echo "<tr>";
            echo "<td>" . $row["medicamento_id"] . "</td>"; // Asegúrate de que la columna 'medicamento_id' exista si la necesitas
            echo "<td>" . $row["nombre"] . "</td>";
            echo "<td>" . $row["descripcion"] . "</td>";
            echo "<td>" . $row["stock"] . "</td>";
            echo "<td>" . $row["precio"] . "</td>";
            echo '<td>
                 
            <a href="actualizarMedicamentos.php?q=' .$row["medicamento_id"].'" class="btn btn-primary">
                <i class="fa fa-pen"></i>
            </a>

         </td>';
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No hay medicamentos disponibles</td></tr>";
    }
}


// Consultar medicamento por ID
function ConsultarMedicamento($medicamento_id) {
    $respuesta = ConsultarMedicamentoBD($medicamento_id);
    if ($respuesta->num_rows > 0) {
        return mysqli_fetch_array($respuesta);
    }
}

// Procesar actualización del medicamento
if (isset($_POST["btnActualizarMedicamento"])) {
    $medicamento_id = $_POST["medicamento_id"];
    $nombre = $_POST["nombre"];
    $descripcion = $_POST["descripcion"];
    $stock = $_POST["stock"];
    $precio = $_POST["precio"];

    ActualizarMedicamento($medicamento_id, $nombre, $descripcion, $stock, $precio);
    header("Location: ../View/VisualizarMedicamentos.php");
    exit();
}


if(isset($_POST["btnRegistrarMedicamento"])) {
    // Asegúrate de que todos los campos están definidos y no están vacíos
    $nombre = isset($_POST["nombre"]) ? trim($_POST["nombre"]) : '';
    $descripcion = isset($_POST["descripcion"]) ? trim($_POST["descripcion"]) : '';
    $stock = isset($_POST["stock"]) ? trim($_POST["stock"]) : '';
    $precio = isset($_POST["precio"]) ? trim($_POST["precio"]) : '';

    if (!empty($nombre) && !empty($descripcion) && !empty($stock) && !empty($precio)) {
        RegistrarMedicamento($nombre, $descripcion, $stock, $precio);
        header("Location: ../View/VisualizarMedicamentos.php");
        exit();
    } else {
        $msj = "Por favor, complete todos los campos.";
        header("Location: ../View/RegistrarMedicamento.php?msj=" . urlencode($msj));
        exit();
    }
}




?>
