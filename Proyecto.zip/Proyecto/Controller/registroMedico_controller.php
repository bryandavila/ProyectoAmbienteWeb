<?php
include_once '../Model/procesar_registro.php';
include_once '../Model/procesar_registroMedico.php';

if (isset($_POST["btnRegistrarUsuario3"])) {
    // Obtener datos del formulario
    $numLicencia = $_POST['numLicencia'];
    $Especialidad = $_POST['Especialidad'];
    

    // Procesar el registro del usuario
    $respuesta_usuario2 = procesarRegistroMedico($numLicencia, $Especialidad);

    if ($respuesta_usuario2 === true) {
        // Obtener el último ID del usuario registrado
        $usuario_id = obtenerUltimoIDUsuario();

        // Procesar el registro del paciente con el usuario_id
        $respuesta_medico = procesarRegistroMedico($numLicencia, $Especialidad);

        // Verificar si el registro del paciente fue exitoso
        if ($respuesta_medico) {
            if ($rol == 1) {
                header("Location: ../View/login.php?identificacion=$identificacion");
            } 
            exit(); // Es una buena práctica salir después de redirigir
        } else {
            echo "Error al registrar el paciente.";
        }
    } else {
        echo "Error al registrar el usuario.";
    }
} else {
    echo "Método no permitido.";
}
?>
