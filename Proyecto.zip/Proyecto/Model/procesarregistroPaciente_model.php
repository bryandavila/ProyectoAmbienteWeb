<?php

include_once 'baseDatosModel.php';

function procesarRegistroPaciente($usuario_id, $fecha_nacimiento, $telefono, $direccion) {
    $conexion = AbrirBaseDatos();
    
    // Asegúrate de que la sentencia sea correcta y que exista el procedimiento almacenado en la base de datos
    $sentencia = "CALL procesarRegistroPaciente(?, ?, ?, ?)";
    $stmt = $conexion->prepare($sentencia);
    $stmt->bind_param("isss", $usuario_id, $fecha_nacimiento, $telefono, $direccion);
    
    $respuesta = $stmt->execute();
    $stmt->close();
    CerrarBaseDatos($conexion);
    
    return $respuesta;

}


function obtenerUltimoIDUsuario() {
        $conexion = AbrirBaseDatos();
        $query = "SELECT obtenerUltimoIDUsuario()";
        $result = $conexion->query($query);
        $row = $result->fetch_array();
        CerrarBaseDatos($conexion);
        
        return $row[0];
    }

    ?>
