<?php
include_once 'baseDatosModel.php';

function ConsultarPacientesDB() {
    $conexion = AbrirBaseDatos();
    $sentencia = "CALL ConsultarPacientes()";
    $respuesta = $conexion->query($sentencia);
    CerrarBaseDatos($conexion);
    return $respuesta;
}

function ConsultarPacienteBD($id) {
    $conexion = AbrirBaseDatos();
    $sentencia = "CALL ConsultarPaciente('$id')";
    $respuesta = $conexion->query($sentencia);
    CerrarBaseDatos($conexion);
    return $respuesta;
}

function ActualizarPaciente($id, $fecha_nacimiento, $direccion, $telefono, $nombre) {
    $conexion = AbrirBaseDatos();
    $sentencia = "CALL ActualizarPaciente('$id', '$fecha_nacimiento', '$direccion', '$telefono', '$nombre')";
    $respuesta = $conexion->query($sentencia);
    CerrarBaseDatos($conexion);
    return $respuesta;
}


function RegistrarPaciente($fecha_nacimiento, $direccion, $telefono, $nombre)
{
    $conexion = AbrirBaseDatos();
    $sentencia = "CALL RegistrarPaciente('$fecha_nacimiento','$direccion','$telefono','$nombre')";
    $respuesta = $conexion -> query($sentencia);
    CerrarBaseDatos($conexion);
    return $respuesta;
}


function CambiarEstadoUsuario($id)
    {
        $conexion = AbrirBaseDatos();
        $sentencia = "CALL CambiarEstadoUsuario('$id')";
        $respuesta = $conexion -> query($sentencia);
        CerrarBaseDatos($conexion);
        return $respuesta;
    }





?>
