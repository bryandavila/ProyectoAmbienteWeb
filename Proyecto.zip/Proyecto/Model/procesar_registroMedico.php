<?php

include_once 'baseDatosModel.php';

function procesarRegistroMedico($numLicencia, $Especialidad) {
    $conexion = AbrirBaseDatos();
    
    // Asegúrate de que la sentencia sea correcta y que exista el procedimiento almacenado en la base de datos
    $sentencia = "CALL procesarRegistroMedico(?, ?)";
    $stmt = $conexion->prepare($sentencia);
    $stmt->bind_param("isss", $numLicencia, $Especialidad);
    
    $respuesta = $stmt->execute();
    $stmt->close();
    CerrarBaseDatos($conexion);
    
    return $respuesta;

}


function obtenerUltimoIDUsuario() {
        $conexion = AbrirBaseDatos();
        $query = "SELECT obtenerUltimoIDUsuario()";
        $result = $conexion->query($query);
        $row = $result->fetch_array();
        CerrarBaseDatos($conexion);
        
        return $row[0];
    }

    ?>