<?php
include_once 'baseDatosModel.php';

function ConsultarMedicamentosDB() {
    $conexion = AbrirBaseDatos();
    $sentencia = "CALL ConsultarMedicamentos()";
    $respuesta = $conexion->query($sentencia);
    CerrarBaseDatos($conexion);
    return $respuesta;
}
function ConsultarMedicamentoBD($medicamento_id) {
    $conexion = AbrirBaseDatos();
    $sentencia = "CALL ConsultarMedicamento('$medicamento_id')";
    $respuesta = $conexion->query($sentencia);
    CerrarBaseDatos($conexion);
    return $respuesta;
}

function ActualizarMedicamento($medicamento_id, $nombre, $descripcion, $stock, $precio) {
    $conexion = AbrirBaseDatos();
    $sentencia = "CALL ActualizarMedicamento('$medicamento_id', '$nombre', '$descripcion', '$stock', '$precio')";
    $respuesta = $conexion->query($sentencia);
    CerrarBaseDatos($conexion);
    return $respuesta;
}

function RegistrarMedicamento($nombre, $descripcion, $stock, $precio)
{
    $conexion = AbrirBaseDatos();
    $sentencia = "CALL RegistrarMedicamento('$nombre','$descripcion','$stock','$precio')";
    $respuesta = $conexion -> query($sentencia);
    CerrarBaseDatos($conexion);
    return $respuesta;
}


?>
