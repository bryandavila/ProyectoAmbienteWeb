<?php 
include_once 'layout.php';
include_once '../Controller/Medicamento_controller.php';

// Consultar datos del medicamento
$datos = ConsultarMedicamento($_GET["q"]);
?>

<!DOCTYPE html>
<html>

<?php 
    HeadCSS();
?>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">

        <?php 
          MostrarNav();
          MostrarMenu();
        ?>

        <div class="content-wrapper">
            <section class="content">

                <div class="content-header">
                    <div class="container-fluid">
                        <h1 class="m-0 text-dark">Datos del Medicamento</h1>
                        <br />
                        <div class="row mb-2">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-8">

                                <?php
                                    if (isset($_POST["msj"])) {
                                        echo '<div class="alert alert-info TextoCentrado">' . $_POST["msj"] . '</div>';
                                    }
                                ?>

                                <form action="../Controller/Medicamento_controller.php" method="post" enctype="multipart/form-data">
                                    <input id="medicamento_id" name="medicamento_id" type="hidden" value="<?php echo $datos["medicamento_id"] ?>">

                                    <label>Nombre</label>
                                    <div class="input-group mb-3">
                                        <input id="nombre" name="nombre" type="text" class="form-control" placeholder="Nombre" required value="<?php echo $datos["nombre"] ?>">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-tag"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <label>Descripción</label>
                                    <div class="input-group mb-3">
                                        <input id="descripcion" name="descripcion" type="text" class="form-control" placeholder="Descripción" required value="<?php echo $datos["descripcion"] ?>">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-file-alt"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <label>Stock</label>
                                    <div class="input-group mb-3">
                                        <input id="stock" name="stock" type="text" class="form-control" placeholder="Stock" required value="<?php echo $datos["stock"] ?>" onkeypress="return SoloNumeros(event)">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-inbox"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <label>Precio</label>
                                    <div class="input-group mb-3">
                                        <input id="precio" name="precio" type="text" class="form-control" placeholder="Precio" required value="<?php echo $datos["precio"] ?>" onkeypress="return SoloMontos(event, this)">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-dollar-sign"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-9"></div>
                                        <div class="col-lg-3 col-md-6 col-sm-6">
                                            <button type="submit" id="btnActualizarMedicamento" name="btnActualizarMedicamento" class="btn btn-primary btn-block">Actualizar</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </section>
        </div>

        <footer class="main-footer">
            <strong>Copyright &copy; 2024</strong>
        </footer>

        <aside class="control-sidebar control-sidebar-dark"></aside>
    </div>

    <?php 
        HeadJS();
    ?>
    <script src="dist/js/productos.js"></script>
</body>

</html>
