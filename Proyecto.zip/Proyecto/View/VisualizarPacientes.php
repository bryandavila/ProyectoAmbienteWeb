<?php   include_once 'layout.php';
        include_once '../Controller/Pacientes_controller.php';
      
        ValidarRolAdministrador();
?>

<!DOCTYPE html>
<html>

<?php 
    HeadCSS();
?>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">

        <?php 
          MostrarNav();
          MostrarMenu();
        ?>

        <div class="content-wrapper">
            <section class="content">

                <div class="content-header">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-12">
                                <h1 class="m-0 text-dark">Consulta de Pacientes</h1>
                                <br/>

                                <?php
                                    if(isset($_POST["msj"]))
                                    {
                                        echo '<div class="alert alert-info TextoCentrado">' . $_POST["msj"] . '</div>';
                                    }
                                ?>

                                <div>
                                    <a class="btn btn-primary" href="registrarPacientes.php">
                                        <i class="fa fa-plus" style="margin-right:5px"> </i>Registrar
                                    </a>
                                </div>
                                <br/>

                                <table id="tablaPacientes" class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID Paciente</th>
                                            <th>Fecha de Nacimiento</th>
                                            <th>Direccion</th>
                                            <th>Telefono</th>
                                            <th>Nombre</th>
                                            <th>Estado</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            ConsultarPacientes();
                                        ?>
                                    </tbody>
                                </table>


                            </div>
                        </div>
                    </div>
                </div>


            </section>
        </div>

        <footer class="main-footer">
            <strong>Copyright &copy; 2024 </strong>
        </footer>

        <aside class="control-sidebar control-sidebar-dark">
        </aside>
    </div>


    <div class="modal fade" id="ModalUsuarios" data-backdrop="static" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content" style="width:600px;">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Confirmación</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="" method="POST">
                    <div class="modal-body">
                        <input type="hidden" id="id" name="id">
                        ¿Desea cambiar el estado del usuario <label id="lblNombre"></label> ?
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" id="btnCambiarEstadoUsuario"
                            name="btnCambiarEstadoUsuario">Procesar</button>
                    </div>
                </form>

            </div>




    <?php 
        HeadJS();
    ?>
    <script>
        $(document).ready(function(){
            $("#tablaPacientes").DataTable({
                language : {
                    url: 'dist/language.json'
                },
                columnDefs:  [{ type: 'string', target: [0,1,2,3,4,5,6]}]
            });
        });
    </script>    
</body>
</html>