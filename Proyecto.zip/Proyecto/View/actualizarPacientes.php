<?php 
include_once 'layout.php';
include_once '../Controller/Pacientes_controller.php';

// Consultar datos del paciente
$datos = ConsultarPaciente($_GET["q"]);
?>

<!DOCTYPE html>
<html>

<?php 
    HeadCSS();
?>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">

        <?php 
          MostrarNav();
          MostrarMenu();
        ?>

        <div class="content-wrapper">
            <section class="content">
                <div class="content-header">
                    <div class="container-fluid">
                        <h1 class="m-0 text-dark">Datos del Paciente</h1>
                        <br />
                        <div class="row mb-2">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-8">

                                <?php
                                    if (isset($_POST["msj"])) {
                                        echo '<div class="alert alert-info TextoCentrado">' . $_POST["msj"] . '</div>';
                                    }
                                ?>

                                <form action="../Controller/Pacientes_controller.php" method="post" enctype="multipart/form-data">
                                    <input id="id" name="id" type="hidden" value="<?php echo $datos["id"] ?>">

                                    <label>Fecha de Nacimiento</label>
                                    <div class="input-group mb-3">
                                        <input id="fecha_nacimiento" name="fecha_nacimiento" type="date" class="form-control" placeholder="Fecha de Nacimiento" required value="<?php echo isset($datos['fecha_nacimiento']) ? $datos['fecha_nacimiento'] : ''; ?>">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-calendar-alt"></span> <!-- Ícono de calendario -->
                                            </div>
                                        </div>
                                    </div>

                                    <label>Direccion</label>
                                    <div class="input-group mb-3">
                                        <input id="direccion" name="direccion" type="text" class="form-control" placeholder="Direccion" required value="<?php echo isset($datos['direccion']) ? $datos['direccion'] : ''; ?>">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-inbox"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <label>Telefono</label>
                                    <div class="input-group mb-3">
                                        <input id="telefono" name="telefono" type="text" class="form-control" placeholder="Telefono" required value="<?php echo isset($datos['telefono']) ? $datos['telefono'] : ''; ?>">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-phone"></span> <!-- Ícono de teléfono -->
                                            </div>
                                        </div>
                                    </div>

                                    <label>Nombre</label>
                                    <div class="input-group mb-3">
                                        <input id="nombre" name="nombre" type="text" class="form-control" placeholder="Nombre" required value="<?php echo isset($datos['nombre']) ? $datos['nombre'] : ''; ?>">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-user"></span> <!-- Ícono de usuario -->
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-9"></div>
                                        <div class="col-lg-3 col-md-6 col-sm-6">
                                            <button type="submit" id="btnActualizarPaciente" name="btnActualizarPaciente" class="btn btn-primary btn-block">Actualizar</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </section>
        </div>

        <footer class="main-footer">
            <strong>Copyright &copy; 2024</strong>
        </footer>

        <aside class="control-sidebar control-sidebar-dark"></aside>
    </div>

    <?php 
        HeadJS();
    ?>
    <script src="dist/js/productos.js"></script>
</body>

</html>
