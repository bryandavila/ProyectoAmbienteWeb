<?php include_once 'layout.php'; ?>
<?php include_once '../Controller/Pacientes_controller.php'; ?>

<!DOCTYPE html>
<html>

<?php 
    HeadCSS();
?>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">

        <?php 
          MostrarNav();
          MostrarMenu();
        ?>

        <div class="content-wrapper">
            <section class="content">
                <div class="content-header">
                    <div class="container-fluid">
                        <h1 class="m-0 text-dark">Datos del Paciente</h1>
                        <br />
                        <div class="row mb-2">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-8">

                                <?php
                                    if(isset($_POST["msj"])) {
                                        echo '<div class="alert alert-info TextoCentrado">' . $_POST["msj"] . '</div>';
                                    }
                                ?>

<form action="" method="post" enctype="multipart/form-data">
    <label>Fecha de Nacimiento</label>
    <div class="input-group mb-3">
        <input id="fecha_nacimiento" name="fecha_nacimiento" type="date" class="form-control" placeholder="Fecha de Nacimiento" required>
        <div class="input-group-append">
            <div class="input-group-text">
                <span class="fas fa-calendar-alt"></span> <!-- Usar un ícono de calendario -->
            </div>
        </div>
    </div>

                                    <label>Direccion</label>
                                    <div class="input-group mb-3">
                                        <input id="direccion" name="direccion" type="text" class="form-control" placeholder="Direccion" required>
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-credit-card"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <label>Telefono</label>
                                    <div class="input-group mb-3">
                                        <input type="number" id="telefono" name="telefono" class="form-control" placeholder="Telefono" required>
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-inbox"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <label>Nombre</label>
                                    <div class="input-group mb-3">
                                        <input type="text"  id="nombre" name="nombre" class="form-control" placeholder="Nombre" required>
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-dollar-sign"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-12 text-center">
                                            <button type="submit" id="btnRegistrarPaciente" name="btnRegistrarPaciente" class="btn btn-primary btn-block">Procesar</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </section>
        </div>

        <footer class="main-footer">
            <strong>Copyright &copy; 2024 </strong>
        </footer>

        <aside class="control-sidebar control-sidebar-dark">
        </aside>
    </div>

    <?php 
        HeadJS();
    ?>
    <script src="dist/js/productos.js"></script>
</body>

</html>
